import { Router } from "express";

const AuthRouter = Router();

AuthRouter.post("/auth/signin", function () {});

AuthRouter.post("/auth/signup", function () {});

AuthRouter.post("/auth/signout", function () {});
